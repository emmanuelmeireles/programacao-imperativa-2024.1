import java.util.Scanner;
public class Main{
	public static void main(String[] args) {
	    
	    Scanner s = new Scanner(System.in);
	    int vol;
	    
		System.out.println("entre com um numero: ");
		vol = s.nextInt();
		
		if (vol<=0){
		    System.out.println("Min Volume");
		}else if ((vol>0)&&(vol<=25)){ 
		    System.out.println("low Volume");
	    }else if ((vol>25)&&(vol<=75)){
	        System.out.println("Medium Volume");
	    }else if ((vol>75)&&(vol<100)){
	        System.out.println("High Volume");
	    }else if (vol>=100){
	        System.out.println("Max Volume");
        }
	}    
}